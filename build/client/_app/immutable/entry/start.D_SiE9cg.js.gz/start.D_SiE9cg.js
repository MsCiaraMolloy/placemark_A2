import{l as o,s as r}from"../chunks/CM1-TOFI.js";export{o as load_css,r as start};
